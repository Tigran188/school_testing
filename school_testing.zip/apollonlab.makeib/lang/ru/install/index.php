<?php
$MESS["MODULE_NAME"] = "тесты и их сдача";
$MESS["DESCRIPTION"] = "заданий для учеников";
$MESS["PARTNER_NAME"] = "ApollonLab";
$MESS["VERSION_ERROR"] = "Версия главного модуля ниже 14. Не поддерживается технология D7, необходимая модулю. Пожалуйста обновите систему.";
$MESS["INSTALL_TITLE"] = "Установка модуля";
$MESS["UNINSTALL_TITLE"] = "Удаление модуля";
$MESS["INSTALL_FINISHED"] = "Модуль установлен";
$MESS["UNINSTALL_FINISHED"] = "Модуль удален";
$MESS["GO_BACK"] = "Вернуться в список";
$MESS["IBLOCK_TYPE_NAME"] = "test_IBlockType_ru";
$MESS["PARTNER_URI"] = "http://testmodule/";
$MESS["TEST_IBLOCK_TYPE_NAME"] = "test_Type";
