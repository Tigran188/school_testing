<?php
$MESS["IBLOCK_TYPE_NAME"] = "test_IBlockType_en";
