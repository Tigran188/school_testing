<?php
$arModuleVersion = [
    "VERSION" => "1.0",
    "VERSION_DATE" => "00:00:00"
];