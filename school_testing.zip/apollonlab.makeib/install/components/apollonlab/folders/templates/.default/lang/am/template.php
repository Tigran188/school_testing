<?php
$MESS['ADD_FOLDER'] = 'Ավելացնել թղթապանակ';