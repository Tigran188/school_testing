<?php
$MESS['GAVE_TIME'] = 'Տրամադրվող ժամանակը';
$MESS['NEXT'] = 'ՀԱՋՈՐԴ';
$MESS['FINISH'] = 'ԱՎԱՐՏԵԼ';
$MESS['POINT'] = 'միավոր';
$MESS['QUESTION'] = 'ՀԱՐՑ';
$MESS['START'] = 'ՍԿՍԵԼ';
$MESS['GIVED_TIME'] = 'Տրամադրվող ժամանակը`';
$MESS['FINISHED'] = 'Ավարտվել է &#128521;';
$MESS['PREVIOUS'] = 'ՆԱԽՈՐԴԸ';