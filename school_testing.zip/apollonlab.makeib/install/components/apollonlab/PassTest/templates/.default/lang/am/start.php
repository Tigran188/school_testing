<?php
$MESS['GIVED_TIME'] = 'Տրամադրվող ժամանակը`';
$MESS['START'] = 'ՍԿՍԵԼ';
