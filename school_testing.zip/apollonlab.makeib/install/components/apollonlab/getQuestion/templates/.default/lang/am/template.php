<?php
$MESS['ADD_QUESTION'] = 'ԱՎԵԼԱՑՆԵԼ ՀԱՐՑ';
$MESS['INPUT_QUESTION'] = 'Գրել հարցը';
$MESS['VERSIONS'] = 'Տարբերակներ';
$MESS['VERSION'] = 'Տարբերակ';
$MESS['INPUT_VERSION'] = 'Գրել տարբերակ';
$MESS['ADD_VERSION'] = 'ավելացնել տարբերակ';
$MESS['SELECT_CORRECT_ANSWER'] = 'Ընտրել ճիշտ պատասխանը';
$MESS['ADD'] = 'ԱՎԵԼԱՑՆԵԼ';
$MESS['CANCEL'] = 'ՉԵՂԱՐԿԵԼ';
$MESS['ADD_CORRECT_ANSWER'] = 'ավելացնել ճիշտ պատասխան';
$MESS['INPUT_CORRECT_ANSWER'] = 'Գրել ճիշտ պատասխանը';
$MESS['INPUT_THEME'] = 'Գրել թեման';
$MESS['AT_LIST_1_ANSWER'] = '- Լրացրեք ամենաքիչը 1 պատասխան';
$MESS['ENTER_QUESTION'] = '- Լրացրեք հարցը';
$MESS['AT_LIST_2_ANSWER'] = '- Լրացրեք ամենաքիչը 2 պատասխան';