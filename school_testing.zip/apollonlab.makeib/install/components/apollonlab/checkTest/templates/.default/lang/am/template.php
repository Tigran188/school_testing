<?php
$MESS['SELECT_ONE_ANSWER'] = 'Ընտրել 1 պատասխան';
$MESS['SELECT_MANY_ANSWER'] = 'Ընտրել 1 կամ մի քանի պատասխան';
$MESS['TASK_OR_QUESTION'] = 'Խնդիր կամ հարց';
$MESS['CORRECT_MISTAKE'] = 'Ուղղել սխալը';
$MESS['ESSE'] = 'Շարադրություն';
$MESS['CONFINE_TEST'] = 'ԱՄՓՈՓԵԼ ԹԵՍՏԸ';
$MESS['CANCEL'] = 'ՉԵՂԱՐԿԵԼ';
$MESS['START'] = 'ՍԿԻԶԲ';
$MESS['END'] = 'ԱՎԱՐՏ';
$MESS['MINUTES'] = 'ՐՈՊԵ';