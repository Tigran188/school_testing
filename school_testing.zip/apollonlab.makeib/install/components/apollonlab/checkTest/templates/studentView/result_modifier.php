<?php

//
//$entity_data_class = $this->GetEntityDataClass(6);
//$testData = $entity_data_class::getList(array(
//    'select' => array('*'),
//    'order' => array(),
//    'filter' => array(
//
//    )
//))->Fetch();