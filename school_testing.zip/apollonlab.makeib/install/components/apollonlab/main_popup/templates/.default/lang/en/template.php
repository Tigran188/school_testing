<?php
$MESS ['VIRTUAL_ROOM'] = "virtual room";