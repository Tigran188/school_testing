<?php
$MESS ['VIRTUAL_ROOM'] = "виртуальная комната";
$MESS ['SCHOOL_USER_NOT_AUTHORIZED'] = "Вы не авторизованы!";