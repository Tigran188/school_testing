<?php
$MESS ['VIRTUAL_ROOM'] = "վիրտուալ սենյակ";