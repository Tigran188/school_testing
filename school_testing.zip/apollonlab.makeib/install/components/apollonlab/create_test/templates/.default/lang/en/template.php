<?php
$MESS['SELECT_SECTIONS_COUNT'] = "ԸՆՏՐԵԼ ԹՂԹԱՊԱՆԱԿՆԵՐԻ ՔԱՆԱԿԸ";
$MESS['TIME_FOR_TEST'] = "ՆՇԵԼ ՏՐԱՄԱԴՐՎՈՐՂ ԺԱՄԱՆԱԿԸ";
$MESS['MK_OPEN'] = "ԴԱՐՁՆԵԼ ԲԱՑ";
$MESS['TO_BACK'] = "ՀԵՏ ՎԵՐԱԴԱՌՆԱԼՈՒ ՀՆԱՐԱՎՈՐՈՒԹՅՈՒՆ";
$MESS['SELECT_SECTION'] = "ԸՆՏՐԵԼ ԹՂԹԱՊԱՆԱԿ";
$MESS['POINT'] = "ՄԻԱՎՈՐ";
$MESS['SELECT_QUESTIONS_COUNT'] = "ԸՆՏՐԵԼ ՀԱՐՑԵՐԻ ՔԱՆԱԿԸ";
$MESS['SAVE'] = "Պահպանել";
$MESS['CANCEL'] = "Չեղարկել";
$MESS['TESTS'] = "ԹԵՍՏԵՐ";
$MESS['INPUT_TEST_NAME'] = "ԳՐԵՔ ԹԵՍՏԻ ԱՆՎԱՆՈՒՄԸ";
$MESS['TEST_IS_READY'] = "Թեստը ստեղծվել է";
$MESS['CREATE_TEST'] = "Ստեղծել թեստ";