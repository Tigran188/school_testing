<?php
$MESS['UPDATE_QUESTION'] = 'ԹԱՐՄԱՑՆԵԼ ՀԱՐՑԸ';
$MESS['INPUT_QUESTION'] = 'Գրել հարցը';
$MESS['INPUT_THEME'] = 'Գրել թեման';
$MESS['VERSIONS'] = 'Տարբերակներ';
$MESS['VERSION'] = 'Տարբերակ';
$MESS['INPUT_VERSION'] = 'Գրել տարբերակ';
$MESS['ADD_VERSION'] = 'ավելացնել տարբերակ';
$MESS['SELECT_CORRECT_ANSWER'] = 'Ընտրել ճիշտ պատասխանը';
$MESS['ADD_CORRECT_ANSWER'] = 'ավելացնել ճիշտ պատասխան';
$MESS['UPDATE'] = 'ԹԱՐՄԱՑՆԵԼ';
$MESS['CANCEL'] = 'ՉԵՂԱՐԿԵԼ';
$MESS['ENTER_CORRECT_ANSWER'] = 'Գրել ճիշտ պատասխանը';