<?php
$MESS['UPDATE_QUESTION'] = 'ԹԱՐՄԱՑՆԵԼ ՀԱՐՑԸ';
$MESS['INPUT_QUESTION'] = 'Գրել հարցը';
$MESS['VERSIONS'] = 'Տարբերակներ';
$MESS['INPUT_VERSION'] = 'Գրել տարբերակ';
$MESS['ADD_VERSION'] = 'ավելացնել տարբերակ';
$MESS['SELECT_CORRECT_ANSWER'] = 'Ընտրել ճիշտ պատասխանը';
$MESS['VERSION'] = 'Տարբերակ';
$MESS['UPDATE'] = 'ԹԱՐՄԱՑՆԵԼ';
$MESS['CANCEL'] = 'ՉԵՂԱՐԿԵԼ';
$MESS['ADD_CORRECT_ANSWER'] = 'ավելացնել ճիշտ պատասխան';
$MESS['ENTER_CORRECT_ANSWER'] = 'Գրել ճիշտ պատասխանը';
$MESS['INPUT_THEME'] = 'Գրել թեման';